package com.example.project1

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.compose.ui.platform.LocalContext

// ViewModel to manage weight data
class WeightViewModel : ViewModel() {
    private var currentWeight: String = "--"
    private var targetWeight: String = "--"
    private val weightHistory: MutableList<String> = mutableListOf()

    fun getCurrentWeight(): String = currentWeight
    fun getTargetWeight(): String = targetWeight
    fun getWeightHistory(): List<String> = weightHistory

    fun setCurrentWeight(weight: String) {
        currentWeight = weight
        weightHistory.add(weight) // Save to history when updated
    }

    fun setTargetWeight(weight: String) {
        targetWeight = weight
    }

    fun deleteLastEntry() {
        if (weightHistory.isNotEmpty()) {
            weightHistory.removeAt(weightHistory.size - 1) // Remove last entry
        }
    }
}

@Composable
fun MainScreen(weightViewModel: WeightViewModel = WeightViewModel()) {
    var currentWeight by remember { mutableStateOf(weightViewModel.getCurrentWeight()) }
    var targetWeight by remember { mutableStateOf(weightViewModel.getTargetWeight()) }
    var weightHistory by remember { mutableStateOf(weightViewModel.getWeightHistory()) }

    // Get the context using LocalContext
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Current Weight: $currentWeight", fontSize = 20.sp)
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = "Target Weight: $targetWeight", fontSize = 20.sp)

        Button(
            onClick = {
                // Show dialog to input weight
                showWeightInputDialog { newWeight ->
                    weightViewModel.setCurrentWeight(newWeight)
                    currentWeight = weightViewModel.getCurrentWeight()
                    weightHistory = weightViewModel.getWeightHistory()
                }
            },
            modifier = Modifier.padding(top = 24.dp)
        ) {
            Text("Enter Weight")
        }

        // Display weight history
        LazyColumn(
            modifier = Modifier.fillMaxHeight(0.5f).padding(top = 16.dp)
        ) {
            items(weightHistory) { weight ->
                Text(text = weight, modifier = Modifier.padding(8.dp))
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 24.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(
                onClick = {
                    // Navigate to NotificationScreen
                    context.startActivity(Intent(context, NotificationScreen::class.java))
                }
            ) {
                Text("Notifications")
            }

            Button(
                onClick = {
                    weightViewModel.deleteLastEntry()
                    currentWeight = weightViewModel.getCurrentWeight()
                    weightHistory = weightViewModel.getWeightHistory()
                }
            ) {
                Text("Delete Entry")
            }
        }
    }
}

// Function to show weight input dialog
private fun showWeightInputDialog(onWeightEntered: (String) -> Unit) {
    // Implementation to show dialog (this would need to be an AlertDialog in a real app)
}
