package com.example.project1

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.CompoundButton
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.project1.ui.theme.Project1Theme

class NotificationScreen : ComponentActivity() {
    private val smsPermissionRequestCode = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            Project1Theme {
                NotificationSettingsScreen()
            }
        }
    }

    @Composable
    fun NotificationSettingsScreen() {
        var dailyReminder by remember { mutableStateOf(false) }
        var weeklyReminder by remember { mutableStateOf(false) }
        var motivationReminder by remember { mutableStateOf(false) }
        var smsNotification by remember { mutableStateOf(false) }
        var smsPermissionStatus by remember { mutableStateOf("SMS Permission Status: Waiting for User Input") }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Top
        ) {
            // Daily Reminder Toggle
            ToggleSetting("Daily Reminder", dailyReminder) { value ->
                dailyReminder = value
            }

            // Weekly Reminder Toggle
            ToggleSetting("Weekly Reminder", weeklyReminder) { value ->
                weeklyReminder = value
            }

            // Motivational Reminder Toggle
            ToggleSetting("Motivation Reminder", motivationReminder) { value ->
                motivationReminder = value
            }

            // SMS Notifications Toggle
            ToggleSetting("SMS Notifications", smsNotification) { value ->
                smsNotification = value
                if (value) {
                    checkSmsPermission()
                }
            }

            // SMS Permission Status Text
            Text(text = smsPermissionStatus, modifier = Modifier.padding(top = 16.dp))
        }

        // Update SMS Permission Status
        LaunchedEffect(smsNotification) {
            smsPermissionStatus = if (smsNotification) {
                if (hasSmsPermission()) {
                    "SMS Permission Status: Granted"
                } else {
                    "SMS Permission Status: Denied"
                }
            } else {
                "SMS Permission Status: Not Required"
            }
        }
    }

    @Composable
    fun ToggleSetting(label: String, isChecked: Boolean, onCheckedChange: (Boolean) -> Unit) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Text(text = label, modifier = Modifier.weight(1f))
            Switch(
                checked = isChecked,
                onCheckedChange = onCheckedChange
            )
        }
    }

    private fun checkSmsPermission() {
        if (!hasSmsPermission()) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.SEND_SMS),
                smsPermissionRequestCode
            )
        }
    }

    private fun hasSmsPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
    }


            }

