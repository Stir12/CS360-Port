package com.example.project1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.project1.ui.theme.Project1Theme

class InputScreen : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            Project1Theme {
                WeightInputScreen()
            }
        }
    }
}

@Composable
fun WeightInputScreen() {
    var weight by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {
        TextField(
            value = weight,
            onValueChange = { weight = it },
            label = { Text("Enter Weight") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            // Logic to save the weight value
            message = "Weight entered: $weight"
            // Update weightViewModel here if needed
        }) {
            Text("Save Weight")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = message)
    }
}
